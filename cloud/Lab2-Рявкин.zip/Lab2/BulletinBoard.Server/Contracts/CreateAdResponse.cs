﻿namespace BulletinBoard.Server.Contracts;

public class CreateAdResponse
{
    public string Message { get; init; } = null!;
}
