﻿namespace BulletinBoard.Server.Contracts;

public class CreateAdContract
{
    public string Advertisement { get; init; } = null!;
}
