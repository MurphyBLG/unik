﻿namespace BulletinBoard.Server.Contracts;

public class GetAllAdsResponse
{
    public string Message { get; init; } = null!;
}
