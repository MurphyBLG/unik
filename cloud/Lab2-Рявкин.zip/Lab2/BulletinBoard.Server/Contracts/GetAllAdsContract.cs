﻿namespace BulletinBoard.Server.Contracts;

public class GetAllAdsContract
{
}
